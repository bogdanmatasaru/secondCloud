#!/usr/bin/env ruby

require './loco/excon.rb'

def fetch_translation(language)
    fetch_file(language, "strings")
    fetch_file(language, "stringsdict")
end


def fetch_file(language, type)
    params = {
        index: "id",
        status: "translated"
    }
    response = Excon.get("https://localise.biz/api/export/locale/#{language}-#{language.upcase}.#{type}?index=text&source=en-GB&status=translated",
                         body: URI.encode_www_form(params), headers: { "Authorization" => ENV["LOCO_AUTHORIZATION"] })
    file_path = "eMag/SupportingFiles/#{language.upcase} version/Localizable.#{type}"
    File.open("../#{file_path}", "wt") do |f|
        puts "Local updated #{language.upcase} Localizable.#{type}"
        f << response.body
    end

    return file_path
end


%w( ro hu bg ).each do |lang|
    fetch_translation(lang)
end
