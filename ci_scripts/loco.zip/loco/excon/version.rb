# frozen_string_literal: true
module Excon
  VERSION = '0.99.0'
end
